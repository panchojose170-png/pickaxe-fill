package mx.pickaxefill;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;

/**
 * Pickaxe Fill:
 * 1) Click derecho (el mismo que abre cofres) con un pico en la mano sobre un bloque = punto 1.
 * 2) Click derecho sobre otro bloque = punto 2, y empieza a minar el área bloque por bloque.
 * Agáchate (shift) + click derecho para cancelar.
 */
public class PickaxeFill implements ModInitializer {
    /** Tope de seguridad para no colgar el servidor con áreas enormes. */
    public static final int MAX_BLOCKS = 100_000;

    private final Map<UUID, BlockPos> firstPoint = new HashMap<>();
    private final Map<UUID, ServerLevel> firstPointLevel = new HashMap<>();
    private final Map<UUID, FillJob> jobs = new HashMap<>();

    /**
     * Muestra un mensaje sobre la barra de objetos. Usa reflexión para funcionar
     * aunque el método cambie de nombre entre versiones de Minecraft.
     */
    public static void msg(ServerPlayer player, String text) {
        Component c = Component.literal(text);
        try {
            try {
                ServerPlayer.class.getMethod("sendOverlayMessage", Component.class).invoke(player, c);
                return;
            } catch (NoSuchMethodException ignored) {
                // probar el siguiente nombre
            }
            try {
                ServerPlayer.class.getMethod("sendSystemMessage", Component.class, boolean.class)
                        .invoke(player, c, true);
                return;
            } catch (NoSuchMethodException ignored) {
                // probar el siguiente nombre
            }
            ServerPlayer.class.getMethod("sendSystemMessage", Component.class).invoke(player, c);
        } catch (Exception ignored) {
            // si no hay forma de mostrar el mensaje, el mod sigue funcionando sin él
        }
    }

    public static boolean isPickaxe(ItemStack stack) {
        return stack.is(ItemTags.PICKAXES);
    }

    @Override
    public void onInitialize() {
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
            if (!isPickaxe(player.getMainHandItem())) return InteractionResult.PASS;

            // En el cliente solo devolvemos SUCCESS para que no se abra el cofre/puerta
            if (!(player instanceof ServerPlayer sp)) {
                return InteractionResult.SUCCESS;
            }

            ServerLevel sl = (ServerLevel) level;
            UUID id = sp.getUUID();
            BlockPos clicked = hit.getBlockPos();

            // Shift + click: cancelar todo
            if (sp.isShiftKeyDown()) {
                FillJob running = jobs.remove(id);
                if (running != null) running.stop("Cancelado.");
                firstPoint.remove(id);
                firstPointLevel.remove(id);
                PickaxeFill.msg(sp, "Marcas borradas.");
                return InteractionResult.SUCCESS;
            }

            if (jobs.containsKey(id)) {
                PickaxeFill.msg(sp, "Ya hay un área minándose. Shift + click derecho para cancelar.");
                return InteractionResult.SUCCESS;
            }

            BlockPos p1 = firstPoint.get(id);
            if (p1 == null || firstPointLevel.get(id) != sl) {
                firstPoint.put(id, clicked.immutable());
                firstPointLevel.put(id, sl);
                PickaxeFill.msg(sp, 
                        "Punto 1: " + clicked.getX() + ", " + clicked.getY() + ", " + clicked.getZ());
                return InteractionResult.SUCCESS;
            }

            // Segundo punto
            long dx = Math.abs(p1.getX() - clicked.getX()) + 1L;
            long dy = Math.abs(p1.getY() - clicked.getY()) + 1L;
            long dz = Math.abs(p1.getZ() - clicked.getZ()) + 1L;
            if (dx * dy * dz > MAX_BLOCKS) {
                PickaxeFill.msg(sp, 
                        "Área demasiado grande (máximo " + MAX_BLOCKS + " bloques).");
                firstPoint.remove(id);
                firstPointLevel.remove(id);
                return InteractionResult.SUCCESS;
            }

            FillJob job = new FillJob(sp, sl, p1, clicked.immutable());
            jobs.put(id, job);
            firstPoint.remove(id);
            firstPointLevel.remove(id);
            PickaxeFill.msg(sp, "Minando " + job.size() + " bloques...");
            return InteractionResult.SUCCESS;
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Iterator<Map.Entry<UUID, FillJob>> it = jobs.entrySet().iterator();
            while (it.hasNext()) {
                FillJob job = it.next().getValue();
                job.tick();
                if (job.isFinished()) it.remove();
            }
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            UUID id = handler.getPlayer().getUUID();
            FillJob job = jobs.remove(id);
            if (job != null) job.stop("");
            firstPoint.remove(id);
            firstPointLevel.remove(id);
        });
    }
}
