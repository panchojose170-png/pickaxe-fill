package mx.pickaxefill;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Trabajo de minado progresivo: cada bloque tarda TICKS_PER_BLOCK ticks
 * (20 ticks = 1 segundo), con grietas y sonidos normales.
 */
public class FillJob {
    public static final int TICKS_PER_BLOCK = 20;

    private final ServerPlayer player;
    private final ServerLevel level;
    private final List<BlockPos> queue;
    private int index = 0;
    private int ticksOnBlock = 0;
    private boolean finished = false;

    public FillJob(ServerPlayer player, ServerLevel level, BlockPos a, BlockPos b) {
        this.player = player;
        this.level = level;
        this.queue = buildQueue(player, a, b);
    }

    public int size() {
        return queue.size();
    }

    public boolean isFinished() {
        return finished;
    }

    /**
     * Orden de rotura:
     * - Si el área es más ancha que alta: filas horizontales, de izquierda a derecha,
     *   subiendo nivel por nivel.
     * - Si es más alta que ancha: columnas verticales, de abajo hacia arriba hasta el tope,
     *   avanzando hacia la derecha.
     * "Izquierda/derecha" se cuentan desde hacia dónde mira el jugador al marcar el segundo punto.
     */
    private static List<BlockPos> buildQueue(ServerPlayer player, BlockPos a, BlockPos b) {
        int minX = Math.min(a.getX(), b.getX()), maxX = Math.max(a.getX(), b.getX());
        int minY = Math.min(a.getY(), b.getY()), maxY = Math.max(a.getY(), b.getY());
        int minZ = Math.min(a.getZ(), b.getZ()), maxZ = Math.max(a.getZ(), b.getZ());

        Direction facing = player.getDirection(); // N/S/E/O horizontal
        Direction right = facing.getClockWise();  // derecha del jugador
        Direction forward = facing;

        // Ejes del área vistos desde el jugador
        int widthSize = Math.abs(right.getStepX()) == 1 ? (maxX - minX + 1) : (maxZ - minZ + 1);
        int depthSize = Math.abs(forward.getStepX()) == 1 ? (maxX - minX + 1) : (maxZ - minZ + 1);
        int heightSize = maxY - minY + 1;

        // Posición inicial en cada eje horizontal según la dirección
        int rightStart = right.getStepX() + right.getStepZ() > 0
                ? (Math.abs(right.getStepX()) == 1 ? minX : minZ)
                : (Math.abs(right.getStepX()) == 1 ? maxX : maxZ);
        int forwardStart = forward.getStepX() + forward.getStepZ() > 0
                ? (Math.abs(forward.getStepX()) == 1 ? minX : minZ)
                : (Math.abs(forward.getStepX()) == 1 ? maxX : maxZ);

        boolean rows = widthSize >= heightSize;
        List<BlockPos> list = new ArrayList<>(widthSize * depthSize * heightSize);

        // Capas de profundidad (de cerca a lejos), y dentro de cada capa el orden pedido
        for (int d = 0; d < depthSize; d++) {
            if (rows) {
                for (int h = 0; h < heightSize; h++) {
                    for (int w = 0; w < widthSize; w++) {
                        list.add(pos(minY + h, rightStart, w, right, forwardStart, d, forward));
                    }
                }
            } else {
                for (int w = 0; w < widthSize; w++) {
                    for (int h = 0; h < heightSize; h++) {
                        list.add(pos(minY + h, rightStart, w, right, forwardStart, d, forward));
                    }
                }
            }
        }
        return list;
    }

    private static BlockPos pos(int y, int rightStart, int w, Direction right,
                                int forwardStart, int d, Direction forward) {
        int x = 0, z = 0;
        // Eje del "right"
        if (Math.abs(right.getStepX()) == 1) {
            x = rightStart + w * right.getStepX();
        } else {
            z = rightStart + w * right.getStepZ();
        }
        // Eje del "forward"
        if (Math.abs(forward.getStepX()) == 1) {
            x = forwardStart + d * forward.getStepX();
        } else {
            z = forwardStart + d * forward.getStepZ();
        }
        return new BlockPos(x, y, z);
    }

    /** Se llama una vez por tick del servidor. */
    public void tick() {
        if (finished) return;

        ItemStack tool = player.getMainHandItem();
        if (!player.isAlive() || !PickaxeFill.isPickaxe(tool)) {
            stop("Se detuvo: ya no tienes el pico en la mano.");
            return;
        }

        // Saltar bloques que no se pueden o no se deben romper
        while (index < queue.size()) {
            BlockPos pos = queue.get(index);
            BlockState state = level.getBlockState(pos);
            if (state.isAir() || state.getDestroySpeed(level, pos) < 0
                    || !tool.isCorrectToolForDrops(state)) {
                index++;
                ticksOnBlock = 0;
                continue;
            }
            break;
        }

        if (index >= queue.size()) {
            stop("Listo.");
            return;
        }

        BlockPos pos = queue.get(index);
        BlockState state = level.getBlockState(pos);
        SoundType sound = state.getSoundType();

        ticksOnBlock++;

        // Grietas: etapa 0..9 según el progreso
        int stage = Math.min(9, (ticksOnBlock * 10) / TICKS_PER_BLOCK);
        level.destroyBlockProgress(player.getId(), pos, stage);

        // Sonido de picado cada 4 ticks, como al minar normal
        if (ticksOnBlock % 4 == 0) {
            level.playSound(null, pos, sound.getHitSound(), SoundSource.BLOCKS,
                    (sound.getVolume() + 1.0F) / 8.0F, sound.getPitch() * 0.5F);
        }

        if (ticksOnBlock >= TICKS_PER_BLOCK) {
            level.destroyBlockProgress(player.getId(), pos, -1);
            // true = suelta los bloques (solo llegamos aquí si el pico es suficiente)
            level.destroyBlock(pos, true, player);
            // Desgaste: 1 de durabilidad por bloque roto
            tool.hurtAndBreak(1, player, EquipmentSlot.MAINHAND);
            index++;
            ticksOnBlock = 0;
        }
    }

    public void stop(String message) {
        if (finished) return;
        finished = true;
        if (index < queue.size()) {
            level.destroyBlockProgress(player.getId(), queue.get(index), -1);
        }
        PickaxeFill.msg(player, message);
    }
}
